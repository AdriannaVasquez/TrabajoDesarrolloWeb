import { Component } from '@angular/core';

@Component({
  selector: 'app-bienestar',
  imports: [],
  templateUrl: './bienestar.html',
  styleUrl: './bienestar.css'
})
export class Bienestar {

}
