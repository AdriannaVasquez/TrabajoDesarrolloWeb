import { Component } from '@angular/core';

@Component({
  selector: 'app-panal',
  imports: [],
  templateUrl: './panal.html',
  styleUrl: './panal.css'
})
export class Panal {

}
