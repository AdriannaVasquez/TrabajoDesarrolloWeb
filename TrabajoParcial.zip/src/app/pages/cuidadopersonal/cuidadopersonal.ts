import { Component } from '@angular/core';

@Component({
  selector: 'app-cuidadopersonal',
  imports: [],
  templateUrl: './cuidadopersonal.html',
  styleUrl: './cuidadopersonal.css'
})
export class Cuidadopersonal {

}
